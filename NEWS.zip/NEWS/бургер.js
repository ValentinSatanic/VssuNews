const navItems = document.querySelectorAll(".nav-item");

navItems.forEach(item => {
  const image = item.querySelector(".меню");
  const settings = item.querySelector(".profile");
  let isSettingsOpen = false;

  function toggleSettingsMenu() {
    isSettingsOpen = !isSettingsOpen;
    settings.style.display = isSettingsOpen ? "block" : "none";
  }

  image.addEventListener("click", toggleSettingsMenu);

  // Обработчик клика на весь документ и загрузки страницы
  document.addEventListener("click", (event) => {
    if (!image.contains(event.target) && isSettingsOpen) {
      toggleSettingsMenu();
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    // isSettingsOpen = false; // Устанавливаем переменную в false
    settings.style.display = 'none'; // Скрываем меню
  });
});
